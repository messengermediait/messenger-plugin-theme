<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://messenger.com.au
 * @since             1.0.0
 * @package           Messenger_Plugin_Theme
 *
 * @wordpress-plugin
 * Plugin Name:       Messenger Plugin and Theme Manager
 * Plugin URI:        http://messenger.com.au/messenger-plugin-theme-uri/
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Messenger
 * Author URI:        http://messenger.com.au/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       messenger-plugin-theme
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'MESSENGER_PLUGIN_THEME_VERSION', '1.0.0' );
define( 'MESSENGER_PLUGIN_THEME_DB_VERSION', '2' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-messenger-plugin-theme-activator.php
 */
function activate_messenger_plugin_theme() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-messenger-plugin-theme-activator.php';
	Messenger_Plugin_Theme_Activator::activate();
}

/**
 * Apply database changes after a plugin update.
 *
 * @since    1.0.0
 */
function maybe_upgrade_messenger_plugin_theme() {
	if ( MESSENGER_PLUGIN_THEME_DB_VERSION === get_option( 'messenger_plugin_theme_db_version' ) ) {
		return;
	}

	activate_messenger_plugin_theme();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-messenger-plugin-theme-deactivator.php
 */
function deactivate_messenger_plugin_theme() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-messenger-plugin-theme-deactivator.php';
	Messenger_Plugin_Theme_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_messenger_plugin_theme' );
register_deactivation_hook( __FILE__, 'deactivate_messenger_plugin_theme' );
add_action( 'plugins_loaded', 'maybe_upgrade_messenger_plugin_theme' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-messenger-plugin-theme.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_messenger_plugin_theme() {

	$plugin = new Messenger_Plugin_Theme();
	$plugin->run();

}
run_messenger_plugin_theme();
