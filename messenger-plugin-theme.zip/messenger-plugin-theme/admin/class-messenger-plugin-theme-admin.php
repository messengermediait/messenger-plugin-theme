<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Messenger_Plugin_Theme
 * @subpackage Messenger_Plugin_Theme/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Messenger_Plugin_Theme
 * @subpackage Messenger_Plugin_Theme/admin
 * @author     Your Name <email@example.com>
 */
class Messenger_Plugin_Theme_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Messenger_Plugin_Theme_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Messenger_Plugin_Theme_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/messenger-plugin-theme-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Messenger_Plugin_Theme_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Messenger_Plugin_Theme_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/messenger-plugin-theme-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function setup_menu() {
		add_menu_page('Messenger Admin', 'Messenger Admin', 'manage_options', 'messenger-admin-options', [$this, 'DisplayMainAdmin']);
	}

	public function handle_create_package() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to create packages.', 'messenger-plugin-theme' ) );
		}

		check_admin_referer( 'messenger_create_package', 'messenger_create_package_nonce' );

		$name = isset( $_POST['package_name'] ) ? sanitize_text_field( wp_unslash( $_POST['package_name'] ) ) : '';
		$type = isset( $_POST['package_type'] ) ? sanitize_text_field( wp_unslash( $_POST['package_type'] ) ) : '';

		if ( '' === $name || ! in_array( $type, array( 'Theme', 'Plugin' ), true ) ) {
			wp_die( esc_html__( 'Enter a package name and select a valid type.', 'messenger-plugin-theme' ) );
		}

		global $wpdb;
		$packages_table = $wpdb->prefix . 'messenger_packages';
		$inserted       = $wpdb->insert(
			$packages_table,
			array(
				'name' => $name,
				'type' => $type,
			),
			array( '%s', '%s' )
		);

		if ( false === $inserted ) {
			wp_die( esc_html__( 'The package could not be created.', 'messenger-plugin-theme' ) );
		}

		$redirect_url = add_query_arg(
			array(
				'page'              => 'messenger-admin-options',
				'package_created'   => '1',
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect_url );
		exit;
	}

	public function DisplayMainAdmin() {
		global $wpdb;

		$packages_table = $wpdb->prefix . 'messenger_packages';
		$installs_table = $wpdb->prefix . 'messenger_installs';
		$releases_table = $wpdb->prefix . 'messenger_package_releases';
		$packages       = $wpdb->get_results(
			"SELECT packages.*, (SELECT COUNT(*) FROM `$installs_table` AS installs WHERE installs.package_id = packages.id) AS installs, (SELECT releases.version FROM `$releases_table` AS releases WHERE releases.package_id = packages.id ORDER BY releases.release_date DESC, releases.id DESC LIMIT 1) AS version FROM `$packages_table` AS packages ORDER BY packages.name ASC"
		);
		$package_id     = isset( $_GET['package_id'] ) ? sanitize_text_field( wp_unslash( $_GET['package_id'] ) ) : null;
		$package        = null;
		$package_installs = array();

		if ( null !== $package_id ) {
			$package = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT packages.*, (SELECT releases.version FROM `$releases_table` AS releases WHERE releases.package_id = packages.id ORDER BY releases.release_date DESC, releases.id DESC LIMIT 1) AS version FROM `$packages_table` AS packages WHERE packages.id = %s",
					$package_id
				)
			);

			if ( $package ) {
				$package_installs = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT id, package_id, site, install_key FROM `$installs_table` WHERE package_id = %s ORDER BY id ASC",
						$package_id
					)
				);
			}
		}
		?>
		<style>
			.messenger-package-container table {
			border: 1px solid rgba(0, 0, 0, 0.5);
			border-radius: 0.5em;
			width: 100%;
			box-shadow: 0px 1px 4px rgba(128, 128, 128, 0.5);
		}
		.messenger-package-container tr:nth-child(odd) {
			background: rgba(255, 255, 255, 0.75);
		}
		.messenger-package-container th {
			background: #fff;
			padding: 0.5em;
			font-size: 1.2em;
			border: 1px solid #fff;
		}
		.messenger-package-container td {
			padding: 0.5em 1.2em;
			font-size: 1.2em;
		}
		a.btn, button.btn {
			margin: 1em;
			display: inline-block;
			box-shadow: 0px 1px 2px #000;
			border-radius: 4px;
			background: #3858e9;
			color: #fff;
			padding: 0.5em;
			text-shadow: 0 1px 1px #000;
			text-decoration: none;
		}
		a.btn.btn-warn {
			background: red;
		}
		.new-version-form {
			transition: all 0.25s;
			opacity: 0;
			max-height: 0px;
			overflow: hidden;
		}
		</style>
		<div class="wrap">
			<h2>Manage Messenger Plugin and Theme Installations</h2>
			<?php if ( null === $package_id ) { ?>
			<div class="messenger-plugin-theme-admin">
				<h3>Packages</h3>
				<?php if ( isset( $_GET['package_created'] ) && '1' === $_GET['package_created'] ) { ?>
					<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Package created.', 'messenger-plugin-theme' ); ?></p></div>
				<?php } ?>
					<div class="messenger-package-container">
						<table>
							<tr><th>Name</th><th>Type</th><th>Version</th><th>Installs</th><th></th></tr>
						<?php
						foreach ( $packages as $package_item ) { ?>
							<tr><td><?php echo esc_html( $package_item->name ); ?></td><td><?php echo esc_html( $package_item->type ); ?></td><td><?php echo esc_html( $package_item->version ); ?></td><td><?php echo esc_html( $package_item->installs ); ?></td><td><a href="?page=messenger-admin-options&amp;package_id=<?php echo rawurlencode( $package_item->id ); ?>" class="btn">View</a></td></tr>
						<?php
						} ?>
						</table>
					</div>
					<div><button type="button" class="btn" onclick="showNewPackageForm()">Create New Package</button></div>
					<div id="new-package-form-container" class="new-version-form">
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="messenger_create_package" />
							<?php wp_nonce_field( 'messenger_create_package', 'messenger_create_package_nonce' ); ?>
							<div><label for="package-name">Name: </label><input type="text" id="package-name" name="package_name" required /></div>
							<div><label for="package-type">Type: </label><select id="package-type" name="package_type" required><option value="Theme">Theme</option><option value="Plugin">Plugin</option></select></div>
							<div><button type="submit">Create Package</button></div>
						</form>
					</div>
					<script>function showNewPackageForm() {
						const container = document.getElementById('new-package-form-container');
						container.style.opacity = 1;
						container.style.maxHeight = '500px';
					}</script>
			</div>
			<?php } elseif ( ! $package ) { ?>
				<p><?php esc_html_e( 'Package not found.', 'messenger-plugin-theme' ); ?></p>
			<?php } else { ?>
			<div class="messenger-plugin-theme-admin">
				<h3><?php echo esc_html( $package->name ); ?> - <?php echo esc_html( $package->type ); ?></h3>
				<div class="messenger-package-container">
					<p><strong>Version: </strong> <?php echo esc_html( $package->version ); ?></p>
					<p><a href="#" download class="btn">Download Zip</a></p>
					<p><em><a href="#">Show previous versions...</a></em></p>
				</div>
				<div class="messenger-package-container">
					<p><strong><button onClick="showNewForm()">Publish New Version...</button></strong></p>
					<div id="new-version-form-container" class="new-version-form">
						<form id="new-version-form">
							<div><label>Version Number: </label><input type="text" id="new-version-number" /></div>
							<div><label>File: </label><input type="file" id="new-version-zip" /></div>
							<div><input type="button" value="Publish" /></div>
						</form>
					</div>
					<script>function showNewForm() {
						const container = document.getElementById('new-version-form-container');
						container.style.opacity = 1;
						container.style.maxHeight = '500px';
					}</script>
				</div>
				<h4>Installations</h4>
				<div class="messenger-package-container">
					<table>
						<tr><th>Site</th><th>Key</th><th>Actions</th></tr>
					<?php
						foreach ( $package_installs as $install ) { ?>
							<tr><td><?php echo esc_html( $install->site ); ?></td><td><?php echo esc_html( $install->install_key ); ?></td><td><a href="#" class="btn">Edit</a><a href="#" class="btn btn-warn">Delete</a></td></tr>
						<?php }
					?>
					</table>
				</div>
			</div>

			<?php }  ?>
		</div>
		<?php
	}

}
