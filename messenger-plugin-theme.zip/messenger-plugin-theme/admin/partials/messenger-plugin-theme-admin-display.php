<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Messenger_Plugin_Theme
 * @subpackage Messenger_Plugin_Theme/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<?php 
function MessengerAdminPage() {
    ?>
    <div class="wrap">
        <h2>Manage Messenger Plugin and Theme Installations</h2>
        <p>Hello</p>
    </div>
    <?php
}
